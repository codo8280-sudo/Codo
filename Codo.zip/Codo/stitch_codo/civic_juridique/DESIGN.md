---
name: Civic Juridique
colors:
  surface: '#f9f9f6'
  surface-dim: '#dadad7'
  surface-bright: '#f9f9f6'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f4f1'
  surface-container: '#eeeeeb'
  surface-container-high: '#e8e8e5'
  surface-container-highest: '#e2e3e0'
  on-surface: '#1a1c1b'
  on-surface-variant: '#3f4943'
  inverse-surface: '#2f312f'
  inverse-on-surface: '#f1f1ee'
  outline: '#6f7a73'
  outline-variant: '#bec9c1'
  surface-tint: '#116b4e'
  primary: '#00563d'
  on-primary: '#ffffff'
  primary-container: '#197052'
  on-primary-container: '#9ff0cb'
  inverse-primary: '#86d7b2'
  secondary: '#5d5e60'
  on-secondary: '#ffffff'
  secondary-container: '#dfdfe0'
  on-secondary-container: '#616364'
  tertiary: '#464b50'
  on-tertiary: '#ffffff'
  tertiary-container: '#5e6368'
  on-tertiary-container: '#dbdfe5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#a2f3cd'
  primary-fixed-dim: '#86d7b2'
  on-primary-fixed: '#002115'
  on-primary-fixed-variant: '#005139'
  secondary-fixed: '#e2e2e3'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1d'
  on-secondary-fixed-variant: '#454748'
  tertiary-fixed: '#dee3e9'
  tertiary-fixed-dim: '#c2c7cc'
  on-tertiary-fixed: '#171c20'
  on-tertiary-fixed-variant: '#42474c'
  background: '#f9f9f6'
  on-background: '#1a1c1b'
  surface-variant: '#e2e3e0'
  pure-surface: '#FFFFFF'
  soft-surface: '#F0F1ED'
  quiet-border: '#E5E6E2'
typography:
  hero-desktop:
    fontFamily: Geist
    fontSize: 4rem
    fontWeight: '700'
    lineHeight: 4.5rem
    letterSpacing: -0.03em
  hero-mobile:
    fontFamily: Geist
    fontSize: 2.5rem
    fontWeight: '700'
    lineHeight: 3rem
    letterSpacing: -0.025em
  h1:
    fontFamily: Geist
    fontSize: 2.75rem
    fontWeight: '600'
    lineHeight: 3.25rem
    letterSpacing: -0.02em
  h1-mobile:
    fontFamily: Geist
    fontSize: 2rem
    fontWeight: '600'
    lineHeight: 2.5rem
    letterSpacing: -0.015em
  h2:
    fontFamily: Geist
    fontSize: 1.875rem
    fontWeight: '600'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  h3:
    fontFamily: Geist
    fontSize: 1.375rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.01em
  body-large:
    fontFamily: Geist
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.875rem
    letterSpacing: 0em
  body:
    fontFamily: Geist
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.65rem
    letterSpacing: 0em
  body-compact:
    fontFamily: Geist
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
    letterSpacing: 0em
  label-code:
    fontFamily: Geist Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
    letterSpacing: 0.02em
  label-code-sm:
    fontFamily: Geist Mono
    fontSize: 0.75rem
    fontWeight: '500'
    lineHeight: 1rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system establishes an authoritative, highly accessible digital civic infrastructure for legal orientation and citizen obligations in Côte d'Ivoire. Rejecting outdated judicial iconography (scales, gavels, classical columns, artificial parchments) and flashy commercial SaaS patterns, the brand manifests as a dependable, sovereign public utility.

The aesthetic philosophy is **Source-First Minimalism**:
- **Legibility over decoration:** Long-form legal reading ergonomics take precedence, utilizing strict line-length constraints (~65 characters) and high-contrast typographic hierarchy.
- **Institutional sobriety:** Grounded neutrals alongside a single civic forest green accent communicate legal precision, administrative certitude, and civic dignity.
- **Authentic traceability:** Every article, law, and administrative synthesis is firmly anchored to an official gazette or institutional body (*Journal Officiel*, *Conseil Constitutionnel*, *Ministère de la Justice*, *OHADA*), surfaced through monospaced indexing and verified attribution tags.
- **Documentary integrity:** Layering is achieved through structural planes, micro-borders, and tactile typographic contrast rather than floating drop-shadows or translucent glassmorphism.

## Colors

The system uses a strictly controlled, high-contrast palette anchored by one civic chromatic accent. Pure black (`#000000`) is prohibited across all text and UI surfaces.

### Core Roles
- **Primary (`#197052` - Civic Green):** The single chromatic accent of the application. Reserved for critical user actions, confirmed status badges, focus boundaries, primary interactive controls, and validated institutional source markers.
- **Secondary (`#181A1B` - Legal Ink):** Primary foreground text color. Provides deep, humanized contrast without the harsh eye-strain of pure digital black. Applied to headers, running body text, and active icon strokes.
- **Tertiary (`#62676C` - Secondary Graphite):** Secondary foreground for article citations, date stamps, auxiliary metadata, breadcrumbs, and inactive state icons.
- **Neutral (`#F8F8F5` - Ivory Canvas):** Foundational canvas color. Replaces stark white with a warm, paper-inspired tone to facilitate fatigue-free legal analysis and prolonged reading.

### Named Surface Tokens
- `pure-surface` (`#FFFFFF`): Applied to elevated documentary cards, active inputs, dropdown sheets, and modal viewports.
- `soft-surface` (`#F0F1ED`): Structural secondary fill for filter pills, table headers, document diff bases, and analytical breakdown backgrounds.
- `quiet-border` (`#E5E6E2`): Crisp 1px structural hairline divider for containers, legal text demarcations, and inputs.

Status validation deliberately avoids multi-colored traffic-light indicators (no red/yellow/green semantic triads). Legal status validity (*En vigueur*, *Abrogé*, *Modifié*) is communicated through typographic tone, explicit copy, and structural border variations.

## Typography

The typographical architecture strictly separates human narrative guidance from formal legal statutory data:
- **`Geist` (Display & Body):** Controls all public explanations, headings, directional UI labels, and conversational legal orientation. Headings feature tight negative letter tracking (`-0.01em` to `-0.03em`) to impart an authoritative, editorial gravitas. Body text is deliberately tuned to a generous line-height (`1.65` to `1.7`) with an optimal reading measure capped at 65 characters per line (`760px – 860px` container width).
- **`Geist Mono` (Legal & Metadata):** Dedicated strictly to legal citations (`LOI N° 2019-574`), article tokens (`ART. 183-C`), official gazette publication dates, system identifiers, and document version comparison logs.

Legacy serif fonts (Times, Georgia, Garamond) are barred to prevent decorative judicial clichés; contemporary geometric sans-serif clarity establishes modern state transparency.

## Layout & Spacing

The layout model is built on an absolute 4px geometric sub-grid, scaling fluidly across three primary responsive contexts:
- **Desktop (≥ 1024px):** 12-column grid. Max-width `1440px`. The legal reading track adheres to a dedicated central column (`760px` to `860px`), with optional asymmetric lateral drawers for statutory citations and metadata index trees.
- **Tablet (768px – 1023px):** 8-column layout. Sidebar content collapses into structured horizontal accordion modules or tabbed document sheets.
- **Mobile (< 768px):** Strict 4-column layout. Multi-column structures collapse vertically; horizontal scrolling is strictly prohibited. Margins contract to `1rem` (`16px`) to maximize surface for legibility.

### Spacing Scale
- `space-xs` (4px): Micro gaps between monospaced law status badges and statutory tags.
- `space-sm` (8px): Internal padding for buttons, pills, status capsules, and item listings.
- `space-md` (16px): Input padding, component groupings, horizontal button internal gutters.
- `space-lg` (24px): Card container padding, document section vertical separation.
- `space-xl` (40px): Section breaks, thematic narrative transitions.

## Elevation & Depth

This system avoids floating elements, synthetic glassmorphism, or deep fuzzy drop shadows. Legal information must feel rooted, permanent, and physically anchored like ink on paper.

Depth is achieved via **Tonal Stacking and Hairline Definition**:
1. **Foundation (Level 0):** `Ivory Canvas` (`#F8F8F5`), representing the natural document table.
2. **Document Surface (Level 1):** `Pure Surface` (`#FFFFFF`), with a 1px boundary (`#E5E6E2`). Used for reading cards, statutory records, and formal advisory outputs.
3. **Document Inset / Auxiliary Surface:** `Soft Surface` (`#F0F1ED`), unbordered or delineated by structural hairlines, used for quote blocks, statutory extracts, and legal diff containers.
4. **Elevated Overlays (Sheets & Modals):** Grounded using `Pure Surface` (`#FFFFFF`) with a sharp, low-opacity tactile boundary and a faint, high-diffusion ambient shadow: `0 4px 24px -2px rgba(24, 26, 27, 0.06)`. Heavy black drop-shadows and saturated glowing halos are prohibited.

## Shapes

The interface embraces a disciplined geometry that strikes an ergonomic balance between civic seriousness and modern tactile usability. Ultra-round pill bubbles (32px+) are prohibited to prevent an informal "social app" appearance, while razor-sharp (0px) corners are avoided to ensure comfortable touch targets on mobile devices.

### Boundary Parameters
- **Status Capsules & Badges:** `8px` (`0.5rem`)
- **Inputs & Standard Buttons:** `12px` (`0.75rem`)
- **Document Cards & Legal Modules:** `16px` (`1rem`)
- **Primary Content Panels & Bottom Sheets:** `24px` (`1.5rem`)

All card structures and form controls implement uniform 1px hairline borders (`#E5E6E2`), transitioning to a crisp 1.5px outline in Civic Green (`#197052`) when active or focused.

## Components

### Buttons
- **Primary Button:** Solid `CODO Civic Green` (`#197052`) fill with `Pure Surface` (`#FFFFFF`) text (`Geist`, medium weight). Height: minimum 48px to preserve touch-target guidelines. On press: `translateY(1px)`.
- **Secondary Button:** `Pure Surface` (`#FFFFFF`) fill, 1px `Quiet Border` (`#E5E6E2`), and `Legal Ink` (`#181A1B`) text. Hover introduces a subtle background shift to `Soft Surface` (`#F0F1ED`).
- **Monospace Action (Copy / Cite):** Inset button in `Geist Mono`, pairing low-contrast graphite icons with concise citation tags (e.g., `COPIER RÉFÉRENCE`).

### Inputs & Universal Search
- **Search Field:** Height 48px to 56px. Background `Pure Surface` (`#FFFFFF`), border 1px `Quiet Border` (`#E5E6E2`).
- **Focus State:** 1.5px border in `CODO Civic Green` (`#197052`) with zero blurry outer glow rings.
- **Labels:** Explicit, persistent upper labels in `Geist` medium text; never rely on disappearing placeholders alone.

### Legal Status Capsules
Small status tags communicate statutory validity without neon hues:
- **En vigueur (In force):** `Soft Surface` (`#F0F1ED`) background, `1px solid #197052`, text `CODO Civic Green` (`#197052`), formatted in `Geist Mono` (`label-code-sm`).
- **Abrogé (Repealed):** `Soft Surface` (`#F0F1ED`) background, `1px solid #62676C`, text `Secondary Graphite` (`#62676C`) with a subtle strike-through accent.
- **Projet de loi (Draft bill):** Dashed 1px border `#62676C` over `Ivory Canvas` (`#F8F8F5`).

### Source Verification Badges
Every piece of legal counsel includes explicit institutional provenance (*Journal Officiel*, *Conseil Constitutionnel*, *Ministère de la Justice*, *OHADA*). Badges are framed with a hairline border, accompanied by a verified stroke icon and a direct link to the statutory publication date. Synthetic percentage bars (e.g. "98% certain") are strictly prohibited.

### Semantic Response Cards
Structured orientation blocks follow an invariant vertical flow:
1. *Votre situation* (Citizen context)
2. *Ce que prévoit le droit* (Statutory baseline)
3. *Ce que vous pouvez faire* (Actionable guidance)
4. *Procédure étape par étape* (Numbered procedural timeline)
5. *Textes applicables & Sources* (`Geist Mono` statute references)

### Checkboxes & Radio Controls
Square 20px inputs with 4px border radius for checkboxes; circular 20px for radios. Unchecked state features 1.5px `#E5E6E2` on `#FFFFFF`. Checked state fills with `#197052` carrying a crisp white geometric check/dot indicator.